#include <stdio.h>

int main()
{
    float basic, salary, da, hra;

    /* Input basic salary of employee */
    printf("Enter basic salary of an employee: ");
    scanf("%f", &basic);


    if(basic <= 15000)
    {
        da  = basic * 0.08;
        hra = basic * 0.05;
    }
    else (basic =>20000)
    {
        da  = basic * 0.10;
        hra = basic * 0.25;
    }
    


    salary = basic + hra + da;

    printf("GROSS SALARY OF EMPLOYEE = %.2f", gross);

    return 0;
}